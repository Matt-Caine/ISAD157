﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ISAD157_MySQL_APP
{
    class DBConnect
    {
        
        internal const string USER_NAME = "ISAD157_MCaine";                //UserName
        internal const string SERVER = "proj-mysql.uopnet.plymouth.ac.uk"; //Server 
        internal const string DATABASE_NAME = "ISAD157_MCaine";            //DBName
        internal const string PASSWORD = "ISAD157_22226511";               //DbPassword
        internal const string SslMode = "none";                            //Security

        
    }
}
